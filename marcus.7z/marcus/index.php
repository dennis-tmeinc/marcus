<!DOCTYPE html>
<?php 
header('Location: dashboard.php');
?><html>
</html>

